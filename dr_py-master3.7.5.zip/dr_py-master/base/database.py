#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# File  : databse.py
# Author: DaShenHan&道长-----先苦后甜，任凭晚风拂柳颜------
# Date  : 2022/9/6

from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()