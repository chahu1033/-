var rule = Object.assign(muban.mxpro,{
	title:'爱看影视',
    host:'https://ikan6.vip',
    url:'/vodshow/fyclass--------fypage---/',
    searchUrl:'/vodsearch/**----------fypage---/',
    class_name:'电影&电视剧&综艺&动漫&日韩剧&美剧&港台剧',
    class_url:'1&2&3&4&15&16&14',
	class_parse:'',
});